//
//  AdamAdapter.h
//  IgaworksAd
//
//  Created by wonje,song on 2014. 4. 10..
//  Copyright (c) 2014년 wonje,song. All rights reserved.
//

#import <AdPopcornDA/DAAdapter.h>


#import "AdamAdView.h"
#import "AdamInterstitial.h"

@interface AdamAdapter : DAAdapter
{
    AdamAdView *_adView;
    AdamInterstitial *_interstitial;
}



@end
