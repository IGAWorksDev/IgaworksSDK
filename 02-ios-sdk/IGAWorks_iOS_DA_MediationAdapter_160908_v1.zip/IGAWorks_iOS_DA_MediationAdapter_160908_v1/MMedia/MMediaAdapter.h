//
//  MMediaAdapter.h
//  IgaworksAd
//
//  Created by wonje,song on 2014. 4. 30..
//  Copyright (c) 2014년 wonje,song. All rights reserved.
//

#import <AdPopcornDA/DAAdapter.h>
#import <MMAdSDK/MMAdSDK.h>

@interface MMediaAdapter : DAAdapter
{
    MMInlineAd *_bannerAdView;
    MMInterstitialAd *_interstitialAd;
    NSTimer *_timer;
}


@end
