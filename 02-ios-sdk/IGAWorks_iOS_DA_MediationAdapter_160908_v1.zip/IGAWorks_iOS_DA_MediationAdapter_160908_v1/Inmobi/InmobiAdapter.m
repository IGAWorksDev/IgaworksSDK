//
//  InmobiAdapter.m
//  IgaworksAd
//
//  Created by wonje,song on 2014. 12. 16..
//  Copyright (c) 2014년 wonje,song. All rights reserved.
//

#import "InmobiAdapter.h"

static inline NSString *DAErrorString(DAErrorCode code)
{
  switch (code)
  {
    case DAException:
      return @"Exception";
    case DAInvalidParameter:
      return @"Invalid Parameter";
    case DAUnknownServerError:
      return @"Unknown Server Error";
    case DAInvalidMediaKey:
      return @"Invalid Media key";
    case DAInvalidSpotKey:
      return @"Invalid Spot key";
    case DAEmptyCampaign:
      return @"Empty Campaign";
    case DANativeSpotDoesNotInitialized:
      return @"Native Spot Does Not Initialized";
    case DAServerTimeout:
      return @"Server Timeout";
    case DALoadAdFailed:
      return @"Load Ad Failed";
    case DANoAd:
      return @"No Ad";
    case DAMediationInvalidIntegrationKey:
      return @"Invalid Integration Key";
    default: {
      return @"Success";
    }
  }
}


@interface InmobiAdapter () <IMBannerDelegate, IMInterstitialDelegate>

@end

@implementation InmobiAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;


- (void)dealloc
{
    [_banner removeFromSuperview];
    _banner = nil;
}

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}

- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(DABannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = DAAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = DAAdInterstitialType;
}

- (BOOL)isSupportInterstitialAd
{
    return YES;
}

- (void)loadAd
{
    NSString *AccountId = [_integrationKey valueForKey:@"AccountID"];
    
    [IMSdk setLogLevel:kIMSDKLogLevelNone];
    [IMSdk initWithAccountID:AccountId];
    
    if (_adType == DAAdBannerType)
    {
        _banner = [[IMBanner alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 50.0f)];
        
        _banner.delegate = self;
        _banner.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        
        // add banner view
        [_bannerView addSubview:_banner];
        
        NSLog(@"loadAd : _bannerView.subviews : %@", _bannerView.subviews);
        
        [self addAlignCenterConstraint];
        
        
        if (_integrationKey != nil)
        {
            NSString *placementKey = [_integrationKey valueForKey:@"PlacementID"];

            unsigned long long longPlacementKey = strtoull([placementKey UTF8String], NULL, 0);
            _banner.placementId = longPlacementKey;
            
          // slot id를 사용하는 경우, 아래에 입력하면 immobi 사이트에서 해당 slot id로 리포트를 확인할 수 있습니다.
            NSLog(@"_banner.placementId : %lld", _banner.placementId);
          
            // load request
            [_banner load];
        }
        else
        {
          if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
          {
            [_delegate DAAdapterBannerView:_banner didFailToReceiveAdWithError:[DAError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
          }
          
          [self closeAd];
        }
    }
    else if (_adType == DAAdInterstitialType)
    {
        NSString *interstitialKey = [_integrationKey valueForKey:@"PlacementID"];
        unsigned long long longInterstitialPlacementKey = strtoull([interstitialKey UTF8String], NULL, 0);
        _interstitial = [[IMInterstitial alloc] initWithPlacementId:longInterstitialPlacementKey];
        _interstitial.delegate = self;
        
        if (_integrationKey != nil)
        {
            NSLog(@"_interstitial.interstitialKey : %@", interstitialKey);
          
          // slot id를 사용하는 경우, 아래에 입력하면 immobi 사이트에서 해당 slot id로 리포트를 확인할 수 있습니다.
          //        _interstitial.slotId = 0;
          
            [_interstitial load];
        }
        else
        {
            if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
            {
              [_delegate DAAdapterInterstitial:_interstitial didFailToReceiveAdWithError:[NSError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
            }
          
            [self closeAd];
        }
    }
}

- (void)closeAd
{
    NSLog(@"%@ : closeAd", self);
    
    
    if (_adType == DAAdBannerType)
    {
        //[_banner stopLoading];
        _banner.delegate = nil;
        [_banner removeFromSuperview];
        _banner = nil;
    }
    else if (_adType == DAAdInterstitialType)
    {
        //[_interstitial stopLoading];
        _interstitial.delegate = nil;
    }
}

- (void)loadRequest
{
    if (_adType == DAAdBannerType)
    {
        [_banner load];
    }
    else if (_adType == DAAdInterstitialType)
    {
        [_interstitial load];
    }
}

- (void)addAlignCenterConstraint
{
    // add constraints
    [_banner setTranslatesAutoresizingMaskIntoConstraints:NO];
    UIView *superview = _bannerView;
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_banner
                                  attribute:NSLayoutAttributeCenterX
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterX
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_banner
                                  attribute:NSLayoutAttributeCenterY
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterY
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_banner
                                                          attribute:NSLayoutAttributeHeight
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeHeight
                                                         multiplier:0.0
                                                           constant:_size.height]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_banner
                                                          attribute:NSLayoutAttributeWidth
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeWidth
                                                         multiplier:0.0
                                                           constant:_size.width]];
}

#pragma mark Banner Request Notifications
/**
 * Callback sent when an ad request loaded an ad. This is a good opportunity
 * to add this view to the hierarchy if it has not yet been added.
 * @param banner The IMBanner instance which finished loading the ad request.
 */
-(void)bannerDidFinishLoading:(IMBanner*)banner
{
    NSLog(@"bannerDidFinishLoading : %@", banner);
    
    
    if ([_delegate respondsToSelector:@selector(DAAdapterBannerViewDidLoadAd:adapter:)])
    {
        [_delegate DAAdapterBannerViewDidLoadAd:banner adapter:self];
    }
}


/**
 * Callback sent when an ad request failed. Normally this is because no network
 * connection was available or no ads were available (i.e. no fill).
 * @param banner The IMBanner instance that failed to load the ad request.
 * @param error The error that occurred during loading.
 */
- (void)banner:(IMBanner*)banner didFailToLoadWithError:(IMRequestStatus*)error
{
    NSLog(@"banner : %@, error : %@", banner, error);
    
    if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate DAAdapterBannerView:banner didFailToReceiveAdWithError:error adapter:self];
    }
    
    [self closeAd];
}


#pragma mark Banner Interaction Notifications
/**
 * Called when the banner is tapped or interacted with by the user
 * Optional data is available to publishers to act on when using
 * monetization platform to render promotional ads.
 * @param banner The IMBanner instance that presents the screen.
 * @param dictionary The NSDictionary containing the parameters as passed by the creative
 */
-(void)bannerDidInteract:(IMBanner *)banner withParams:(NSDictionary *)dictionary
{
    
}
/**
 * Callback sent just before when the banner is presenting a full screen view
 * to the user. Use this opportunity to stop animations and save the state of
 * your application in case the user leaves while the full screen view is on
 * screen (e.g. to visit the App Store from a link on the full screen view).
 * @param banner The IMBanner instance that presents the screen.
 */
- (void)bannerWillPresentScreen:(IMBanner *)banner
{
    
}


/**
 * Callback sent just before dismissing the full screen view.
 * @param banner The IMBanner instance that dismisses the screen.
 */
- (void)bannerWillDismissScreen:(IMBanner *)banner
{
    
}
/**
 * Callback sent just after dismissing the full screen view.
 * Use this opportunity to restart anything you may have stopped as part of
 * bannerWillPresentScreen: callback.
 * @param banner The IMBanner instance that dismissed the screen.
 */
- (void)bannerDidDismissScreen:(IMBanner *)banner
{
    
}
/**
 * Callback sent just before the application goes into the background because
 * the user clicked on a link in the ad that will launch another application
 * (such as the App Store). The normal UIApplicationDelegate methods like
 * applicationDidEnterBackground: will immediately be called after this.
 * @param banner The IMBanner instance that is launching another application.
 */
- (void)bannerWillLeaveApplication:(IMBanner *)banner
{
    NSLog(@"_bannerView.subviews : %@", _bannerView.subviews);
    
    
    if ([_delegate respondsToSelector:@selector(DAAdapterBannerViewWillLeaveApplication:)])
    {
        [_delegate DAAdapterBannerViewWillLeaveApplication:banner];
    }
}

#pragma mark Interstitial Request Notifications

/**
 * Sent when an interstitial ad request succeeded.
 * @param ad The IMInterstitial instance which finished loading.
 */
- (void)interstitialDidFinishLoading:(IMInterstitial *)interstitial
{
    
    if ([_interstitial isReady]) {
        [_interstitial showFromViewController:_viewController];
    }
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitialAdDidLoadAd:)])
    {
        [_delegate DAAdapterInterstitialAdDidLoadAd:interstitial];
    }
}


/**
 * Sent when an interstitial ad request failed
 * @param ad The IMInterstitial instance which failed to load.
 * @param error The IMError associated with the failure.
 */
- (void)interstitial:(IMInterstitial *)interstitial didFailToLoadWithError:(IMRequestStatus *)error
{
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate DAAdapterInterstitial:interstitial didFailToReceiveAdWithError:error adapter:self];
    }
}

#pragma mark Interstitial Interaction Notifications

/**
 * Sent just before presenting an interstitial.  After this method finishes the
 * interstitial will animate onto the screen.  Use this opportunity to stop
 * animations and save the state of your application in case the user leaves
 * while the interstitial is on screen (e.g. to visit the App Store from a link
 * on the interstitial).
 * @param ad The IMInterstitial instance which will present the screen.
 */
- (void)interstitialWillPresentScreen:(IMInterstitial *)interstitial
{
    
}

/**
 * Sent before the interstitial is to be animated off the screen.
 * @param ad The IMInterstitial instance which will dismiss the screen.
 */
- (void)interstitialWillDismissScreen:(IMInterstitial *)interstitial
{
    
}


/**
 * Sent just after dismissing an interstitial and it has animated off the screen.
 * @param ad The IMInterstitial instance which was responsible for dismissing the screen.
 */
- (void)interstitialDidDismissScreen:(IMInterstitial *)interstitial
{
    
}

/**
 * Callback sent just before the application goes into the background because
 * the user clicked on a link in the ad that will launch another application
 * (such as the App Store). The normal UIApplicationDelegate methods like
 * applicationDidEnterBackground: will immediately be called after this.
 * @param ad The IMInterstitial instance that is launching another application.
 */
- (void)interstitialWillLeaveApplication:(IMInterstitial *)interstitial
{
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitialWillLeaveApplication:)])
    {
        [_delegate DAAdapterInterstitialWillLeaveApplication:interstitial];
    }
}

/**
 * Called when the interstitial is tapped or interacted with by the user
 * Optional data is available to publishers to act on when using
 * monetization platform to render promotional ads.
 * @param ad The IMInterstitial instance which was responsible for this action.
 * @param dictionary The NSDictionary object which was passed from the ad.
 */
-(void)interstitialDidInteract:(IMInterstitial *)interstitial withParams:(NSDictionary *)dictionary
{
    
}
/**
 * Called when the interstitial failed to display.
 * This should normally occur if the state != kIMInterstitialStateReady.
 * @param ad The IMInterstitial instance responsible for this error.
 * @param error The IMError associated with this failure.
 */
- (void)interstitial:(IMInterstitial *)interstitial didFailToPresentScreenWithError:(IMRequestStatus *)error
{
    
}
@end
