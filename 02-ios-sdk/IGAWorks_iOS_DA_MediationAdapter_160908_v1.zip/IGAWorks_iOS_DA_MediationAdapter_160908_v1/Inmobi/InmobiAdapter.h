//
//  InmobiAdapter.h
//  IgaworksAd
//
//  Created by wonje,song on 2014. 12. 16..
//  Copyright (c) 2014년 wonje,song. All rights reserved.
//

#import <AdPopcornDA/DAAdapter.h>
#import "IMSdk.h"

#import "IMBanner.h"
#import "IMInterstitial.h"
#import "IMInterstitialDelegate.h"

@interface InmobiAdapter : DAAdapter
{
    IMBanner *_banner;
    IMInterstitial *_interstitial;
}

@end
