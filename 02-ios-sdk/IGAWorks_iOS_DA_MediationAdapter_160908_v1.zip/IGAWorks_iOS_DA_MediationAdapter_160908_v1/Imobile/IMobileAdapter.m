//
//  ImobileAdapter.m
//  IgaworksAd
//
//  Created by wonje,song on 2015. 3. 23..
//  Copyright (c) 2015년 wonje,song. All rights reserved.
//

#import "IMobileAdapter.h"

@interface IMobileAdapter () <IMobileSdkAdsDelegate> {

  NSString *_sid;
  BOOL _isInterstitialAdLoaded;
}

//- (void)showAd:(id)sender;

@end

@implementation IMobileAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;

- (void)dealloc
{

}

- (instancetype)init
{
  self = [super init];
  if (self) {
    
  }
  
  return self;
}

- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(DABannerView *)bannerView
{
  _viewController = viewController;
  _origin = origin;
  _size = size;
  _bannerView = bannerView;
  _adType = DAAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
  _viewController = viewController;
  _adType = DAAdInterstitialType;
}

- (BOOL)isSupportInterstitialAd
{
  return YES;
}

- (void)loadAd
{
  
  NSString *pid = @"";
  NSString *mid = @"";
  
  if (_adType == DAAdBannerType)
  {
    
    NSLog(@"ImobileAdapter : _integrationKey : %@", _integrationKey);
    
    if (_integrationKey != nil)
    {
      pid = [_integrationKey valueForKey:@"publisherId"];
      mid = [_integrationKey valueForKey:@"mediaId"];
      _sid = [_integrationKey valueForKey:@"spotId"];
      
      [ImobileSdkAds registerWithPublisherID:pid MediaID:mid SpotID:_sid];
      [ImobileSdkAds startBySpotID:_sid];
      [ImobileSdkAds setAdOrientation:IMOBILESDKADS_AD_ORIENTATION_AUTO];
      
      [ImobileSdkAds setSpotDelegate:_sid delegate:self];
      
      [ImobileSdkAds showBySpotID:_sid ViewController:_viewController Position:_origin];
    }

  }
  else if (_adType == DAAdInterstitialType)
  {
    if (_integrationKey != nil)
    {
      pid = [_integrationKey valueForKey:@"publisherId"];
      mid = [_integrationKey valueForKey:@"mediaId"];
      _sid = [_integrationKey valueForKey:@"spotId"];
      
      [ImobileSdkAds registerWithPublisherID:pid MediaID:mid SpotID:_sid];
      [ImobileSdkAds setSpotDelegate:_sid delegate:self];
      
      [ImobileSdkAds startBySpotID:_sid];
      
//      [ImobileSdkAds showBySpotID:_sid];
      
      
//      UIButton *showAdButton = [UIButton buttonWithType:UIButtonTypeContactAdd];
//      showAdButton.frame = CGRectMake(100.0f, 200.0f, 60.0f, 30.0f);
//      [_viewController.view addSubview:showAdButton];
      
//      [showAdButton addTarget:self action:@selector(showAd:) forControlEvents:UIControlEventTouchUpInside];
    }
  }
}

- (void)loadRequest
{
  // adjust banner view frame
  NSObject *object = [_viewController.view.subviews lastObject];
  UIView *view = (UIView *)object;
  
  view.frame = _bannerView.frame;
  
}

- (void)closeAd
{
  NSLog(@"%@ : closeAd", self);
  
//  [ImobileSdkAds stop];
  
  [ImobileSdkAds stopBySpotID:_sid];
  
  if (_adType == DAAdBannerType)
  {
      NSObject *object = [_viewController.view.subviews lastObject];
      UIView *view = (UIView *)object;
      [view removeFromSuperview];
    
      NSLog(@"3. - (void)closeAd : _viewController : %@, _viewController.view.subviews : %@", _viewController, _viewController.view.subviews);
  }
}

- (void)showInterstitialAd
{
  [ImobileSdkAds showBySpotID:_sid];
}


#pragma mark - IMobileSdkAdsDelegate

- (void)imobileSdkAdsSpot:(NSString *)spotId didReadyWithValue:(ImobileSdkAdsReadyResult)value
{
  NSLog(@"- (void)imobileSdkAdsSpot:(NSString *)spotId didReadyWithValue:(ImobileSdkAdsReadyResult)value : %@, %u", spotId, value);
 
  
  if ([_delegate respondsToSelector:@selector(DAAdapterInterstitialAdDidLoadAd:)])
  {
    [_delegate DAAdapterInterstitialAdDidLoadAd:[ImobileSdkAds self]];
  }
}


// 広告の取得を失敗した際に呼ばれます
- (void)imobileSdkAdsSpot:(NSString *)spotId didFailWithValue:(ImobileSdkAdsFailResult)value
{
  NSLog(@"- (void)imobileSdkAdsSpot:(NSString *)spotId didFailWithValue:(ImobileSdkAdsFailResult)value : %@, %u", spotId, value);
  
  
  [self closeAd];
  
  if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
  {
    [_delegate DAAdapterInterstitial:[ImobileSdkAds self] didFailToReceiveAdWithError:[NSError errorWithDomain:kDAErrorDomain code:value userInfo:@{NSLocalizedDescriptionKey: @""}] adapter:self];
  }
}

// 広告の表示要求があった際に、準備が完了していない場合に呼ばれます
- (void)imobileSdkAdsSpotIsNotReady:(NSString *)spotId
{
  NSLog(@"- (void)imobileSdkAdsSpotIsNotReady:(NSString *)spotId : %@", spotId);
}

// 広告クリックした際に呼ばれます
- (void)imobileSdkAdsSpotDidClick:(NSString *)spotId
{
  NSLog(@"- (void)imobileSdkAdsSpotDidClick:(NSString *)spotId : %@", spotId);
}

// 広告を閉じた際に呼ばれます(広告の表示がスキップされた場合も呼ばれます)
- (void)imobileSdkAdsSpotDidClose:(NSString *)spotId
{
  NSLog(@"- (void)imobileSdkAdsSpotDidClose:(NSString *)spotId : %@", spotId);
}

// 広告の表示が完了した際に呼ばれます
- (void)imobileSdkAdsSpotDidShow:(NSString *)spotId
{
  
  NSLog(@"- (void)imobileSdkAdsSpotDidShow:(NSString *)spotId : %@", spotId);
}

// フィルターモードの情報が取得完了した際に呼ばれます
- (void)imobileSdkAdsSpotDidGetFilterMode:(NSString *)spotId
{
  NSLog(@"- (void)imobileSdkAdsSpotDidGetFilterMode:(NSString *)spotId : %@", spotId);
}

@end
