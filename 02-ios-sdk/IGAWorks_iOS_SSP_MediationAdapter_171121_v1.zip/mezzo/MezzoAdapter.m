//
//  MezzoAdapter.m
//  AdPopcornSSP
//
//  Created by mick on 2017. 9. 6..
//  Copyright (c) 2017년 igaworks All rights reserved.
//

#import "MezzoAdapter.h"

static inline NSString *SSPErrorString(SSPErrorCode code)
{
    switch (code)
    {
        case AdPopcornSSPException:
            return @"Exception";
        case AdPopcornSSPInvalidParameter:
            return @"Invalid Parameter";
        case AdPopcornSSPUnknownServerError:
            return @"Unknown Server Error";
        case AdPopcornSSPInvalidMediaKey:
            return @"Invalid Media key";
        case AdPopcornSSPInvalidPlacementId:
            return @"Invalid Placement id";
        case AdPopcornSSPEmptyCampaign:
            return @"Empty Campaign";
        case AdPopcornSSPNativePlacementDoesNotInitialized:
            return @"Native Placement Does Not Initialized";
        case AdPopcornSSPServerTimeout:
            return @"Server Timeout";
        case AdPopcornSSPLoadAdFailed:
            return @"Load Ad Failed";
        case AdPopcornSSPNoAd:
            return @"No Ad";
        case AdPopcornSSPMediationInvalidIntegrationKey:
            return @"Invalid Integration Key";
        default: {
            return @"Success";
        }
    }
}


@interface MezzoAdapter () <ADBannerDelegate, ManInterstitialDelegate>
{
    
}

- (void)addAlignCenterConstraint;
@end

@implementation MezzoAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}


- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(AdPopcornSSPBannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = SSPAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPAdInterstitialType;
}

- (BOOL)isSupportInterstitialAd
{
    return YES;
}

- (void)loadAd
{
    if (_adType == SSPAdBannerType)
    {
        if (_integrationKey != nil)
        {
            NSString *publisherCode = [_integrationKey valueForKey:@"PublisherCode"];
            NSString *mediaCode = [_integrationKey valueForKey:@"MediaCode"];
            NSString *sectionCode = [_integrationKey valueForKey:@"SectionCode"];
            
            NSLog(@"SSPAdBannerType PublisherCode : %@", publisherCode);
            NSLog(@"SSPAdBannerType MediaCode : %@", mediaCode);
            NSLog(@"SSPAdBannerType SectionCode : %@", sectionCode);
          
            if(_size.width == 300.0f && _size.height == 250.0f)
            {
                NSLog(@"%@ : MezzoMedia can not load 300x250", self);
                if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
                {
                    [_delegate AdPopcornSSPAdapterBannerView:nil didFailToReceiveAdWithError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
                }
                
                [self closeAd];
                return;
            }
            // 배너 리사이징 처리
            CGFloat bannerLimitHeight = 64.0f;                                                                      // 최대 세로 리사이징 제한사이즈
            CGFloat bannerFrameWidth = MIN(_bannerView.bounds.size.width, _bannerView.bounds.size.height);              // 배너 가로 프레임 사이즈(디바이스의 portrait 가로사이즈 기준)
            CGFloat bannerFrameHeight = bannerFrameWidth / MAN_BANNER_RATIO;                                        // 배너 세로 프레임 사이즈
            bannerFrameHeight = (bannerFrameHeight > bannerLimitHeight)? bannerLimitHeight : bannerFrameHeight;     // 배너 세로 프레임 사이즈 보정 (제한 사이즈를 넘지 않도록 보정)
            
            _adBannerView = [[ADBanner alloc] initWithFrame:CGRectMake(0, 0, _bannerView.bounds.size.width, bannerFrameHeight)];
            
            // 발급받은 publisher id와 media id, section id 설정
            [_adBannerView publisherID:publisherCode mediaID:mediaCode sectionID:sectionCode];
            // viewController 객체 넘겨준다.
            _adBannerView.delegate = self;
            // 광고뷰의 가로 사이즈를 뷰에 자동으로 맞춘다.
            _adBannerView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
            
            // add banner view
            [_bannerView addSubview:_adBannerView];
            
            [self addAlignCenterConstraint];
            
            [_adBannerView startBannerAd];
            
        }
        else
        {
          if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
          {
            [_delegate AdPopcornSSPAdapterBannerView:_adBannerView didFailToReceiveAdWithError:[AdPopcornSSPError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
          }
          
          [self closeAd];
        }
    }
    else if (_adType == SSPAdInterstitialType)
    {
        if (_integrationKey != nil)
        {
            NSString *publisherCode = [_integrationKey valueForKey:@"PublisherCode"];
            NSString *mediaCode = [_integrationKey valueForKey:@"MediaCode"];
            NSString *sectionCode = [_integrationKey valueForKey:@"SectionCode"];
            
            NSLog(@"SSPAdInterstitialType PublisherCode : %@", publisherCode);
            NSLog(@"SSPAdInterstitialType MediaCode : %@", mediaCode);
            NSLog(@"SSPAdInterstitialType SectionCode : %@", sectionCode);
            
            _interstitial = [ManInterstitial shareInstance];
            _interstitial.delegate = self;
            [_interstitial publisherID:publisherCode mediaID:mediaCode sectionID:sectionCode];
            [_interstitial startInterstitial];
        }
        else
        {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
            {
              [_delegate AdPopcornSSPAdapterInterstitial:_interstitial didFailToReceiveAdWithError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
          
            [self closeAd];
        }
    }
}

- (void)showAd
{
    NSLog(@"%@ : showAd", self);
    // Load/show 한번에
}

- (void)closeAd
{
    NSLog(@"%@ : closeAd", self);
    
    if (_adType == SSPAdBannerType)
    {
        [_adBannerView removeFromSuperview];
        _adBannerView.delegate = nil;
        _adBannerView = nil;
    }
    else if (_adType == SSPAdInterstitialType)
    {
        _interstitial.delegate = nil;
        _interstitial = nil;
    }
}

- (void)loadRequest
{
    if (_adType == SSPAdBannerType)
    {
        [_adBannerView startBannerAd];
    }
    else if (_adType == SSPAdInterstitialType)
    {
        [_interstitial startInterstitial];
    }
}

- (void)addAlignCenterConstraint
{
    // add constraints
    [_adBannerView setTranslatesAutoresizingMaskIntoConstraints:NO];
    UIView *superview = _bannerView;
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_adBannerView
                                  attribute:NSLayoutAttributeCenterX
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterX
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_adBannerView
                                  attribute:NSLayoutAttributeCenterY
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterY
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adBannerView
                                                          attribute:NSLayoutAttributeHeight
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeHeight
                                                         multiplier:0.0
                                                           constant:_size.height]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adBannerView
                                                          attribute:NSLayoutAttributeWidth
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeWidth
                                                         multiplier:0.0
                                                           constant:_size.width]];
}

#pragma - ADBannerDelegate
/* 배너 클릭에 따른 이벤트를 통보.
 */
- (void)adBannerClick:(ADBanner*)adBanner
{
    NSLog(@"MezzoAdapter adBannerClick");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewWillLeaveApplication:)])
    {
        [_delegate AdPopcornSSPAdapterBannerViewWillLeaveApplication:adBanner];
    }
}

/* 광고 노출 준비가 되었음을 통보.
 */
- (void)adBannerParsingEnd:(ADBanner*)adBanner
{
    
}

/* 광고 수신 성공
 chargedAdType 유료광고 인지 무료광고 인지 구별
 YES 이면 유료 광고, NO 이면 무료 광고.
 */
- (void)didReceiveAd:(ADBanner*)adBanner chargedAdType:(BOOL)bChargedAdType
{
    NSLog(@"MezzoAdapter didReceiveAd");
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewDidLoadAd:adapter:)])
    {
        [_delegate AdPopcornSSPAdapterBannerViewDidLoadAd:adBanner adapter:self];
    }
}

/* 배너 광고 수신 에러
 */
- (void)didFailReceiveAd:(ADBanner*)adBanner errorType:(NSInteger)errorType
{
    NSLog(@"MezzoAdapter didFailToReceiveAd : %ld", (long)errorType);

    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate AdPopcornSSPAdapterBannerView:adBanner didFailToReceiveAdWithError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
    }
}

/* 배너 광고 클릭시 나타났던 랜딩 페이지가 닫힐 경우
 */
- (void)didCloseRandingPage:(ADBanner*)adBanner
{
    
}

/* 배너 부정 재요청 (지정된 시간 이내에 재요청이 발생함)
 */
- (void)didBlockReloadAd:(ADBanner*)adBanner
{
    
}


#pragma mark - ManInterstitialDelegate
-(void)didReceiveInterstitial {
    // 전면광고 수신 성공
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdDidLoadAd:)])
    {
        [_delegate AdPopcornSSPAdapterInterstitialAdDidLoadAd:_interstitial];
    }
}

-(void)didFailReceiveInterstitial :(NSInteger)errorType {
    // 전면광고 수신에러
    [self closeAd];
    
    NSLog(@"MezzoAdapter didFailReceiveInterstitial : %ld", (long)errorType);

    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate AdPopcornSSPAdapterInterstitial:_interstitial didFailToReceiveAdWithError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPLoadAdFailed userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPLoadAdFailed)}] adapter:self];
    }
}

-(void)didCloseInterstitial {
    // 전면광고 닫힘
}

@end
