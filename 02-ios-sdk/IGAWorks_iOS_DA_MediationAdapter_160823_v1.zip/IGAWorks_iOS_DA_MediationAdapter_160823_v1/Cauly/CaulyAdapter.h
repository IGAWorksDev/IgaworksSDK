//
//  CaulyAdapter.h
//  IgaworksAd
//
//  Created by wonje,song on 2014. 4. 10..
//  Copyright (c) 2014년 wonje,song. All rights reserved.
//

#import <AdPopcornDA/DAAdapter.h>

#import "CaulyAdView.h"
#import "CaulyInterstitialAd.h"

@interface CaulyAdapter : DAAdapter
{
    CaulyAdView *_adView;
    CaulyInterstitialAd *_interstitialAd;
}





@end
