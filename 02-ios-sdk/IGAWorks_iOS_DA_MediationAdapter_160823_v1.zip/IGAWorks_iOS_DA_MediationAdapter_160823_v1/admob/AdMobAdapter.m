//
//  AdMobAdapter.m
//  IgaworksAd
//
//  Created by wonje,song on 2014. 5. 9..
//  Copyright (c) 2014년 wonje,song. All rights reserved.
//

#import "AdMobAdapter.h"

static inline NSString *DAErrorString(DAErrorCode code)
{
  switch (code)
  {
    case DAException:
      return @"Exception";
    case DAInvalidParameter:
      return @"Invalid Parameter";
    case DAUnknownServerError:
      return @"Unknown Server Error";
    case DAInvalidMediaKey:
      return @"Invalid Media key";
    case DAInvalidSpotKey:
      return @"Invalid Spot key";
    case DAEmptyCampaign:
      return @"Empty Campaign";
    case DANativeSpotDoesNotInitialized:
      return @"Native Spot Does Not Initialized";
    case DAServerTimeout:
      return @"Server Timeout";
    case DALoadAdFailed:
      return @"Load Ad Failed";
    case DANoAd:
      return @"No Ad";
    case DAMediationInvalidIntegrationKey:
      return @"Invalid Integration Key";
    default: {
      return @"Success";
    }
  }
}


@interface AdMobAdapter () <GADBannerViewDelegate, GADInterstitialDelegate>
{
    
}

@property (NS_NONATOMIC_IOSONLY, readonly, copy) GADRequest *request;
- (void)addAlignCenterConstraint;
@end

@implementation AdMobAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;



- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}


- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(DABannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = DAAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = DAAdInterstitialType;
}

- (BOOL)isSupportInterstitialAd
{
    return YES;
}

- (void)loadAd
{
    if (_adType == DAAdBannerType)
    {
        _adBannerView = [[GADBannerView alloc] initWithAdSize:kGADAdSizeBanner origin:CGPointMake(0.0f, 0.0f)];
        
        _adBannerView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        
        // add banner view
        [_bannerView addSubview:_adBannerView];
        
        [self addAlignCenterConstraint];
        
        
        if (_integrationKey != nil)
        {
            _adBannerView.adUnitID = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
          
          NSLog(@"_adBannerView.adUnitID : %@", _adBannerView.adUnitID);
          
          _adBannerView.delegate = self;
          _adBannerView.rootViewController = _viewController;
          
          // load request
          [_adBannerView loadRequest:[self request]];
        }
        else
        {
          if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
          {
            
            
            [_delegate DAAdapterBannerView:_adBannerView didFailToReceiveAdWithError:[DAError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
          }
          
          [self closeAd];
        }
      
        
        /*
         UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
         
         if (UIInterfaceOrientationIsPortrait(orientation))
         {
         _adBannerView.adSize = GADAdSizeFullWidthPortraitWithHeight(50.0f);
         }
         else if (UIInterfaceOrientationIsLandscape(orientation))
         {
         _adBannerView.adSize = GADAdSizeFullWidthLandscapeWithHeight(32.0f);
         }
         
         // add banner view
         [_bannerView addSubview:_adBannerView];
         */
    }
    else if (_adType == DAAdInterstitialType)
    {
        // Create a new GADInterstitial each time.  A GADInterstitial will only show one request in its
        // lifetime. The property will release the old one and set the new one.
        _interstitial = [[GADInterstitial alloc] init];
        _interstitial.delegate = self;
        
        // Note: Edit SampleConstants.h to update kSampleAdUnitId with your interstitial ad unit id.
        
        if (_integrationKey != nil)
        {
            NSLog(@"_integrationKey : %@", _integrationKey);
            
            _interstitial.adUnitID = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
          
            [_interstitial loadRequest:[self request]];
        }
        else
        {
            if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
            {
              [_delegate DAAdapterInterstitial:_interstitial didFailToReceiveAdWithError:[NSError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
            }
          
            [self closeAd];
        }
    }
}

- (void)closeAd
{
    NSLog(@"%@ : closeAd", self);
    
    if (_adType == DAAdBannerType)
    {
        [_adBannerView removeFromSuperview];
        _adBannerView = nil;
    }
    else if (_adType == DAAdInterstitialType)
    {
        
    }
}

- (void)loadRequest
{
    if (_adType == DAAdBannerType)
    {
        [_adBannerView loadRequest:[self request]];
    }
    else if (_adType == DAAdInterstitialType)
    {
        [_interstitial loadRequest:[self request]];
    }
}

- (void)addAlignCenterConstraint
{
    // add constraints
    [_adBannerView setTranslatesAutoresizingMaskIntoConstraints:NO];
    UIView *superview = _bannerView;
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_adBannerView
                                  attribute:NSLayoutAttributeCenterX
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterX
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_adBannerView
                                  attribute:NSLayoutAttributeCenterY
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterY
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adBannerView
                                                          attribute:NSLayoutAttributeHeight
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeHeight
                                                         multiplier:0.0
                                                           constant:_size.height]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adBannerView
                                                          attribute:NSLayoutAttributeWidth
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeWidth
                                                         multiplier:0.0
                                                           constant:_size.width]];
}

#pragma mark GADRequest generation
- (GADRequest *)request
{
    GADRequest *request = [GADRequest request];
    
    // Make the request for a test ad. Put in an identifier for the simulator as well as any devices
    // you want to receive test ads.
    //    request.testDevices = @[
    // TODO: Add your device/simulator test identifiers here. Your device identifier is printed to
    // the console when the app is launched.
    //                            GAD_SIMULATOR_ID, @"2c127c4d3ac4eaaf79c48dc9e700e905"
    //                            ];
    
    return request;
}

#pragma mark - GADBannerViewDelegate
- (void)adViewDidReceiveAd:(GADBannerView *)view
{
    NSLog(@"GADBannerView : %@", view);
    
    
    if ([_delegate respondsToSelector:@selector(DAAdapterBannerViewDidLoadAd:adapter:)])
    {
        [_delegate DAAdapterBannerViewDidLoadAd:view adapter:self];
    }
}

- (void)adView:(GADBannerView *)view didFailToReceiveAdWithError:(GADRequestError *)error
{
    
    NSLog(@"view : %@, error : %@", view, error);
    
    if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate DAAdapterBannerView:view didFailToReceiveAdWithError:error adapter:self];
    }
    
    [self closeAd];
}

- (void)adViewWillPresentScreen:(GADBannerView *)adView
{
    
}


- (void)adViewWillDismissScreen:(GADBannerView *)adView
{
    
}


- (void)adViewDidDismissScreen:(GADBannerView *)adView
{
    
}

- (void)adViewWillLeaveApplication:(GADBannerView *)adView
{
    if ([_delegate respondsToSelector:@selector(DAAdapterBannerViewWillLeaveApplication:)])
    {
        [_delegate DAAdapterBannerViewWillLeaveApplication:adView];
    }
}

#pragma mark - GADInterstitialDelegate
#pragma mark Ad Request Lifecycle Notifications

// Sent when an interstitial ad request succeeded.  Show it at the next
// transition point in your application such as when transitioning between view
// controllers.
- (void)interstitialDidReceiveAd:(GADInterstitial *)ad
{
    [_interstitial presentFromRootViewController:_viewController];
    
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitialAdDidLoadAd:)])
    {
        [_delegate DAAdapterInterstitialAdDidLoadAd:ad];
    }
}

// Sent when an interstitial ad request completed without an interstitial to
// show.  This is common since interstitials are shown sparingly to users.
- (void)interstitial:(GADInterstitial *)ad didFailToReceiveAdWithError:(GADRequestError *)error
{
    
    [self closeAd];
    
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate DAAdapterInterstitial:ad didFailToReceiveAdWithError:error adapter:self];
    }
}

#pragma mark Display-Time Lifecycle Notifications

// Sent just before presenting an interstitial.  After this method finishes the
// interstitial will animate onto the screen.  Use this opportunity to stop
// animations and save the state of your application in case the user leaves
// while the interstitial is on screen (e.g. to visit the App Store from a link
// on the interstitial).
- (void)interstitialWillPresentScreen:(GADInterstitial *)ad
{
    
}

// Sent before the interstitial is to be animated off the screen.
- (void)interstitialWillDismissScreen:(GADInterstitial *)ad
{
    
}

// Sent just after dismissing an interstitial and it has animated off the
// screen.
- (void)interstitialDidDismissScreen:(GADInterstitial *)ad
{
    
}

// Sent just before the application will background or terminate because the
// user clicked on an ad that will launch another application (such as the App
// Store).  The normal UIApplicationDelegate methods, like
// applicationDidEnterBackground:, will be called immediately before this.
- (void)interstitialWillLeaveApplication:(GADInterstitial *)ad
{
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitialWillLeaveApplication:)])
    {
        [_delegate DAAdapterInterstitialWillLeaveApplication:ad];
    }
}



@end