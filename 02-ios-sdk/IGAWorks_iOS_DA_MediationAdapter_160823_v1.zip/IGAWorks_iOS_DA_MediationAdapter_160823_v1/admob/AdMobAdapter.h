//
//  AdMobAdapter.h
//  IgaworksAd
//
//  Created by wonje,song on 2014. 5. 9..
//  Copyright (c) 2014년 wonje,song. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>


#import <AdPopcornDA/DAAdapter.h>

@interface AdMobAdapter : DAAdapter
{
    GADBannerView *_adBannerView;
    GADInterstitial *_interstitial;
}


@end