//
//  AdamAdWrapperView.h
//  AdamPublisher
//  Version 2.3.1
//
//  Copyright 2012 Daum Communications. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AdamAdWrapperView : UIView

- (void)displayAdView;

@end
