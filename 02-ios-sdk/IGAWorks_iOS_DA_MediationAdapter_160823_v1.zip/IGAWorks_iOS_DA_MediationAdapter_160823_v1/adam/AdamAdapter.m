//
//  AdamAdapter.m
//  IgaworksAd
//
//  Created by wonje,song on 2014. 4. 10..
//  Copyright (c) 2014년 wonje,song. All rights reserved.
//

#import "AdamAdapter.h"

static inline NSString *DAErrorString(DAErrorCode code)
{
  switch (code)
  {
    case DAException:
      return @"Exception";
    case DAInvalidParameter:
      return @"Invalid Parameter";
    case DAUnknownServerError:
      return @"Unknown Server Error";
    case DAInvalidMediaKey:
      return @"Invalid Media key";
    case DAInvalidSpotKey:
      return @"Invalid Spot key";
    case DAEmptyCampaign:
      return @"Empty Campaign";
    case DANativeSpotDoesNotInitialized:
      return @"Native Spot Does Not Initialized";
    case DAServerTimeout:
      return @"Server Timeout";
    case DALoadAdFailed:
      return @"Load Ad Failed";
    case DANoAd:
      return @"No Ad";
    case DAMediationInvalidIntegrationKey:
      return @"Invalid Integration Key";
    default: {
      return @"Success";
    }
  }
}

@interface AdamAdapter () <AdamAdViewDelegate, AdamInterstitialDelegate>
{
    
}

- (void)addAlignCenterConstraint;
@end

@implementation AdamAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}


- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(DABannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = DAAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = DAAdInterstitialType;
}

- (BOOL)isSupportInterstitialAd
{
    return YES;
}

- (void)loadAd
{
    if (_adType == DAAdBannerType)
    {
        if (_adView.superview == nil)
        {
            _adView = [AdamAdView sharedAdView];
            
            _adView.frame = CGRectMake(0.0f, 0.0f, _size.width, _size.height);
            _adView.delegate = self;
            _adView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
            
            if (_integrationKey != nil)
            {
                _adView.clientId = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
                NSLog(@"_adView.clientId : %@", _adView.clientId);
              
              [_adView startAutoRequestAd:_bannerView.adRefreshRate];
              
              // add banner view
              [_bannerView addSubview:_adView];
              
              [self addAlignCenterConstraint];
            }
            else
            {
              if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
              {
                
                [_delegate DAAdapterBannerView:_adView didFailToReceiveAdWithError:[DAError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
              }
              
              [self closeAd];
            }
        }
    }
    else if (_adType == DAAdInterstitialType)
    {
        _interstitial = [AdamInterstitial sharedInterstitial];
        _interstitial.delegate = self;
        
        if (_integrationKey != nil)
        {
          _interstitial.clientId = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
          NSLog(@"_interstitial.clientId : %@", _interstitial.clientId);
          
          [_interstitial requestAndPresent];
        }
        else
        {
          if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
          {
            [_delegate DAAdapterInterstitial:_interstitial didFailToReceiveAdWithError:[NSError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
          }
          
          [self closeAd];
        }
    }
}


- (void)closeAd
{
    NSLog(@"%@ : closeAd", self);
    
    
    if (_adType == DAAdBannerType)
    {
        [_adView stopAutoRequestAd];
        
        [_adView removeFromSuperview];
        _adView = nil;
    }
    else if (_adType == DAAdInterstitialType)
    {
        
    }
}


- (void)setAge:(NSInteger)age
{
    
    [_adView setBirth:@"yyyy----"];
}

- (void)setGender:(DAGender)gender
{
    NSString *genderString = @"";
    if (gender == DAGenderMale)
    {
        genderString = @"M";
    }
    else if (gender == DAGenderFemale)
    {
        genderString = @"F";
    }
    
    [_adView setGender:genderString];
}


- (void)addAlignCenterConstraint
{
    // add constraints
    [_adView setTranslatesAutoresizingMaskIntoConstraints:NO];
    UIView *superview = _bannerView;
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_adView
                                  attribute:NSLayoutAttributeCenterX
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterX
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_adView
                                  attribute:NSLayoutAttributeCenterY
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterY
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView
                                                          attribute:NSLayoutAttributeHeight
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeHeight
                                                         multiplier:0.0
                                                           constant:_size.height]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView
                                                          attribute:NSLayoutAttributeWidth
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeWidth
                                                         multiplier:0.0
                                                           constant:_size.width]];
}

#pragma mark - AdamAdViewDelegate
- (void)didReceiveAd:(AdamAdView *)adView
{
    if ([_delegate respondsToSelector:@selector(DAAdapterBannerViewDidLoadAd:adapter:)])
    {
        [_delegate DAAdapterBannerViewDidLoadAd:adView adapter:self];
    }
}

- (void)didFailToReceiveAd:(AdamAdView *)adView error:(NSError *)error
{
    NSLog(@"adView : %@, error : %@", adView, error);
    
    
    if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate DAAdapterBannerView:adView didFailToReceiveAdWithError:error adapter:self];
    }
    
    [self closeAd];
}

- (void)willOpenFullScreenAd:(AdamAdView *)adView
{
    
}

- (void)didOpenFullScreenAd:(AdamAdView *)adView
{
    
}

- (void)willCloseFullScreenAd:(AdamAdView *)adView
{
    
}

- (void)didCloseFullScreenAd:(AdamAdView *)adView
{
    
}

- (void)willResignByAd:(AdamAdView *)adView
{
    
}

#pragma mark - AdamInterstitialDelegate
/**
 전면형 광고 수신 성공시 호출되는 메소드.
 @param interstitial 광고 수신 성공 이벤트가 발생한 AdamInterstitial 객체.
 */
- (void)didReceiveInterstitialAd:(AdamInterstitial *)interstitial
{
    NSLog(@"interstitial : %@", interstitial);
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitialAdDidLoadAd:)])
    {
        [_delegate DAAdapterInterstitialAdDidLoadAd:interstitial];
    }
}

/**
 전면형 광고 수신 실패시 호출되는 메소드.
 광고 수신에 실패한 원인을 알고자 하는 경우, error.localizedDescription 값을 출력해보면 된다.
 @param interstitial 광고 수신 실패 이벤트가 발생한 AdamInterstitial 객체.
 @param error 광고 수신에 실패한 원인이 되는 error 객체.
 */
- (void)didFailToReceiveInterstitialAd:(AdamInterstitial *)interstitial error:(NSError *)error
{
    [self closeAd];
    
    NSLog(@"interstitial : %@, error : %@", interstitial, error);
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate DAAdapterInterstitial:interstitial didFailToReceiveAdWithError:error adapter:self];
    }
}

/**
 전면형 광고가 보여질 때 호출되는 메소드.
 @param interstitial 전면형 광고 열림 이벤트가 발생한 AdamInterstitial 객체.
 */
- (void)willOpenInterstitialAd:(AdamInterstitial *)interstitial
{
    
}

/**
 전면형 광고가 보여진 직후 호출되는 메소드.
 @param interstitial 전면형 광고 열림 완료 이벤트가 발생한 AdamInterstitial 객체.
 */
- (void)didOpenInterstitialAd:(AdamInterstitial *)interstitial
{
    
}

/**
 전면형 광고가 닫힐 때 호출되는 메소드.
 @param interstitial 전면형 광고 닫힘 이벤트가 발생한 AdamInterstitial 객체.
 */
- (void)willCloseInterstitialAd:(AdamInterstitial *)interstitial
{
    
}

/**
 전명형 광고가 닫힌 직후 호출되는 메소드.
 @param interstitial 전면형 광고 닫힘 완료 이벤트가 발생한 AdamInterstitial 객체.
 */
- (void)didCloseInterstitialAd:(AdamInterstitial *)interstitial
{
    
}

/**
 전면형 광고 내부의 인터랙션에 의해 애플리케이션이 종료될 때 호출되는 메소드.
 전면형 광고 내부에서 전화 걸기 또는 앱스토어로 이동 기능 등이 실행되는 경우, 애플리케이션이 백그라운드로 들어가게 될 때 호출된다.
 @param interstitial 백그라운드로 전환 이벤트를 발생시킨 AdamInterstitial 객체.
 */
- (void)willResignByInterstitialAd:(AdamInterstitial *)interstitial
{
    
}


@end
