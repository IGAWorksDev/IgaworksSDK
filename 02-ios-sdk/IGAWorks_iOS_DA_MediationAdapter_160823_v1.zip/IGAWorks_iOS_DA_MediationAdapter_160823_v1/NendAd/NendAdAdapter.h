//
//  NendAdAdapter.h
//  IgaworksAd
//
//  Created by wonje,song on 2015. 3. 12..
//  Copyright (c) 2015년 wonje,song. All rights reserved.
//
#import <AdPopcornDA/DAAdapter.h>
#import "NADView.h"
#import "NADInterstitial.h"

@interface NendAdAdapter : DAAdapter
{
  NADView *_adView;
  
}

- (void)showInterstitialAd;

@end
