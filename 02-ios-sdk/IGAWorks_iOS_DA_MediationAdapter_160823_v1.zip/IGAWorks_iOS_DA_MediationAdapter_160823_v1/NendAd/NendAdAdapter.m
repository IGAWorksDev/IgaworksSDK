//
//  NendAdAdapter.m
//  IgaworksAd
//
//  Created by wonje,song on 2015. 3. 12..
//  Copyright (c) 2015년 wonje,song. All rights reserved.
//

#import "NendAdAdapter.h"

static inline NSString *DAErrorString(DAErrorCode code)
{
  switch (code)
  {
    case DAException:
      return @"Exception";
    case DAInvalidParameter:
      return @"Invalid Parameter";
    case DAUnknownServerError:
      return @"Unknown Server Error";
    case DAInvalidMediaKey:
      return @"Invalid Media key";
    case DAInvalidSpotKey:
      return @"Invalid Spot key";
    case DAEmptyCampaign:
      return @"Empty Campaign";
    case DANativeSpotDoesNotInitialized:
      return @"Native Spot Does Not Initialized";
    case DAServerTimeout:
      return @"Server Timeout";
    case DALoadAdFailed:
      return @"Load Ad Failed";
    case DANoAd:
      return @"No Ad";
    case DAMediationInvalidIntegrationKey:
      return @"Invalid Integration Key";
    default: {
      return @"Success";
    }
  }
}


@interface NendAdAdapter () <NADViewDelegate, NADInterstitialDelegate>
{
  BOOL _isInterstitialAdLoaded;
}

- (void)addAlignCenterConstraint;

@end


@implementation NendAdAdapter
@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;


- (instancetype)init
{
  self = [super init];
  if (self) {
    
  }
  
  return self;
}

- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(DABannerView *)bannerView
{
  _viewController = viewController;
  _origin = origin;
  _size = size;
//  _bannerView = bannerView;
  _adType = DAAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
  _viewController = viewController;
  _adType = DAAdInterstitialType;
}

- (BOOL)isSupportInterstitialAd
{
  return YES;
}

- (void)loadAd
{
  if (_adType == DAAdBannerType)
  {
    if (_adView.superview == nil)
    {
      _adView = [[NADView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, _size.width, _size.height)];
        
//        _adView = [[NADView alloc] init];
        [_adView setAutoresizingMask:UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin];
        
      _adView.isOutputLog = YES;
      
      _adView.delegate = self;
//      _adView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        
        _adView.backgroundColor = [UIColor cyanColor];
      

      NSLog(@"_integrationKey : %@", _integrationKey);
      
      if (_integrationKey != nil)
      {
        if ([_integrationKey valueForKey:@"apiKey"] != nil && [_integrationKey valueForKey:@"spotID"] != nil)
        {
          [_adView setNendID:[_integrationKey valueForKey:@"apiKey"] spotID:[_integrationKey valueForKey:@"spotID"]];
          
          [_adView load];
          
          // add banner view
          [_bannerView addSubview:_adView];
            
            
        
          
          [self addAlignCenterConstraint];
        }
        else
        {
          if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
          {
            [_delegate DAAdapterBannerView:_adView didFailToReceiveAdWithError:[DAError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
          }
          
          [self closeAd];
        }
      }
      else
      {
        if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
        {
          [_delegate DAAdapterBannerView:_adView didFailToReceiveAdWithError:[DAError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
        }
        
        
        [self closeAd];
      }
    }
  }
  else if (_adType == DAAdInterstitialType)
  {
    [NADInterstitial sharedInstance].delegate = self;
    
    if (_integrationKey != nil)
    {
      if ([_integrationKey valueForKey:@"apiKey"] != nil && [_integrationKey valueForKey:@"spotID"] != nil)
      {
        
        
        NSLog(@"_integrationKey : %@", _integrationKey);
        
        [[NADInterstitial sharedInstance] loadAdWithApiKey:[_integrationKey valueForKey:@"apiKey"] spotId:[_integrationKey valueForKey:@"spotID"]];
        
//        [[NADInterstitial sharedInstance] loadAdWithApiKey:@"308c2499c75c4a192f03c02b2fcebd16dcb45cc9" spotId:@"213208"];
      }
      else
      {
        if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
        {
          [_delegate DAAdapterInterstitial:[NADInterstitial sharedInstance] didFailToReceiveAdWithError:[NSError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
        }
        
        [self closeAd];
      }
      
    }
    else
    {
      if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
      {
        [_delegate DAAdapterInterstitial:[NADInterstitial sharedInstance] didFailToReceiveAdWithError:[NSError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
      }
      
      [self closeAd];
    }
  }
  
  
}


- (void)closeAd
{
  NSLog(@"%@ : closeAd", self);
  
  
  if (_adType == DAAdBannerType)
  {
    [_adView pause];
    
    [_adView removeFromSuperview];
    _adView = nil;
  }
  else if (_adType == DAAdInterstitialType)
  {
    
  }
}

// for interstitial ad
- (void)showInterstitialAd
{
  
  [[NADInterstitial sharedInstance] showAd];
}



#pragma mark - private method
- (void)addAlignCenterConstraint
{
  // add constraints
  [_adView setTranslatesAutoresizingMaskIntoConstraints:NO];
  UIView *superview = _bannerView;
    
    
  [superview addConstraint:
   [NSLayoutConstraint constraintWithItem:_adView
                                attribute:NSLayoutAttributeCenterX
                                relatedBy:NSLayoutRelationEqual
                                   toItem:superview
                                attribute:NSLayoutAttributeCenterX
                               multiplier:1
                                 constant:0]];
  
  [superview addConstraint:
   [NSLayoutConstraint constraintWithItem:_adView
                                attribute:NSLayoutAttributeCenterY
                                relatedBy:NSLayoutRelationEqual
                                   toItem:superview
                                attribute:NSLayoutAttributeCenterY
                               multiplier:1
                                 constant:0]];
  
  [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView
                                                        attribute:NSLayoutAttributeHeight
                                                        relatedBy:NSLayoutRelationEqual
                                                           toItem:superview
                                                        attribute:NSLayoutAttributeHeight
                                                       multiplier:0.0
                                                         constant:_size.height]];
  
  [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView
                                                        attribute:NSLayoutAttributeWidth
                                                        relatedBy:NSLayoutRelationEqual
                                                           toItem:superview
                                                        attribute:NSLayoutAttributeWidth
                                                       multiplier:0.0
                                                         constant:_size.width]];
}

#pragma mark - NADViewDelegate
- (void)nadViewDidReceiveAd:(NADView *)adView
{
  if ([_delegate respondsToSelector:@selector(DAAdapterBannerViewDidLoadAd:adapter:)])
  {
    [_delegate DAAdapterBannerViewDidLoadAd:adView adapter:self];
  }
}

- (void)nadViewDidFinishLoad:(NADView *)adView
{

}

- (void)nadViewDidClickAd:(NADView *)adView
{

}

- (void)nadViewDidFailToReceiveAd:(NADView *)adView
{
  NSLog(@"adView : %@", adView);
  
  
  if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
  {
    [_delegate DAAdapterBannerView:adView didFailToReceiveAdWithError:nil adapter:self];
  }
  
  [self closeAd];
}

#pragma mark - NADInterstitialDelegate
- (void)didFinishLoadInterstitialAdWithStatus:(NADInterstitialStatusCode)status
{
  NSLog(@"- (void)didFinishLoadInterstitialAdWithStatus:(NADInterstitialStatusCode)status : status : %d", status);
}

- (void)didFinishLoadInterstitialAdWithStatus:(NADInterstitialStatusCode)status spotId:(NSString *)spotId
{
  NSLog(@"didFinishLoadInterstitialAdWithStatus:status : %d spotId : %@", status, spotId);
  
//  [_interstitial dismissAd];
  
  if (status == SUCCESS)
  {
    /*
    if (!_isInterstitialAdLoaded) {
      [_interstitial showAd];
    
      _isInterstitialAdLoaded = YES;
    
      if ([_delegate respondsToSelector:@selector(DAAdapterInterstitialAdDidLoadAd:)])
      {
        [_delegate DAAdapterInterstitialAdDidLoadAd:_interstitial];
      }
    }
     */
    
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitialAdDidLoadAd:)])
    {
      [_delegate DAAdapterInterstitialAdDidLoadAd:[NADInterstitial sharedInstance]];
    }
  }
  else
  {
    [self closeAd];
    
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
    {
      [_delegate DAAdapterInterstitial:[NADInterstitial sharedInstance] didFailToReceiveAdWithError:[NSError errorWithDomain:@"NendAd" code:status userInfo:nil] adapter:self];
    }
  }
  
}

- (void)didClickWithType:(NADInterstitialClickType)type
{
  NSLog(@"didClickWithType : %d", type);
}

- (void)didClickWithType:(NADInterstitialClickType)type spotId:(NSString *)spotId
{
  NSLog(@"didClickWithType : %d, spotId : %@", type, spotId);
  
  [[NADInterstitial sharedInstance] dismissAd];
}


@end
