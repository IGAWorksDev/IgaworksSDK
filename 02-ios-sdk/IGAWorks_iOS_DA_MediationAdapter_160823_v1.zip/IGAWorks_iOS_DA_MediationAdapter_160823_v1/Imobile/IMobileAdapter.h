//
//  ImobileAdapter.h
//  IgaworksAd
//
//  Created by wonje,song on 2015. 3. 23..
//  Copyright (c) 2015년 wonje,song. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <AdPopcornDA/DAAdapter.h>

#import "ImobileSdkAds/ImobileSdkAds.h"

@interface IMobileAdapter : DAAdapter
{
  UIView *_adView;
}

- (void)showInterstitialAd;



@end
