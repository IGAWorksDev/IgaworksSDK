//
//  TAdAdapter.h
//  IgaworksAd
//
//  Created by wonje,song on 2014. 4. 11..
//  Copyright (c) 2014년 wonje,song. All rights reserved.
//

#import <AdPopcornDA/DAAdapter.h>

#import "TadCore.h"

@interface TAdAdapter : DAAdapter
{
    TadCore *_adCore;
    UIView * _adView;
}


@end
