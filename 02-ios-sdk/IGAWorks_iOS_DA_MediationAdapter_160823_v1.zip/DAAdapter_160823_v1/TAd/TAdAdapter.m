//
//  TAdAdapter.m
//  IgaworksAd
//
//  Created by wonje,song on 2014. 4. 11..
//  Copyright (c) 2014년 wonje,song. All rights reserved.
//

#import "TAdAdapter.h"


static inline NSString *DAErrorString(DAErrorCode code)
{
  switch (code)
  {
    case DAException:
      return @"Exception";
    case DAInvalidParameter:
      return @"Invalid Parameter";
    case DAUnknownServerError:
      return @"Unknown Server Error";
    case DAInvalidMediaKey:
      return @"Invalid Media key";
    case DAInvalidSpotKey:
      return @"Invalid Spot key";
    case DAEmptyCampaign:
      return @"Empty Campaign";
    case DANativeSpotDoesNotInitialized:
      return @"Native Spot Does Not Initialized";
    case DAServerTimeout:
      return @"Server Timeout";
    case DALoadAdFailed:
      return @"Load Ad Failed";
    case DANoAd:
      return @"No Ad";
    case DAMediationInvalidIntegrationKey:
      return @"Invalid Integration Key";
    default: {
      return @"Success";
    }
  }
}

@interface TAdAdapter () <TadDelegate>
{
    
}

- (void)addAlignCenterConstraint;

@end

@implementation TAdAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}


- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(DABannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = DAAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = DAAdInterstitialType;
}

- (BOOL)isSupportInterstitialAd
{
    return YES;
}


- (void)loadAd
{
    if (_adCore)
    {
        [_adCore destroyAd];
        _adCore = nil;
    }
    
    if (_adType == DAAdBannerType)
    {
        _adView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f,  _size.width, _size.height)];
        _adView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        
        // add banner view
        [_bannerView addSubview:_adView];
        
        [self addAlignCenterConstraint];
        
        _adCore = [[TadCore alloc] initWithSeedView:_adView delegate:self];

        if (_integrationKey != nil)
        {
            _adCore.clientID = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
          
            NSLog(@"_adCore.clientID : %@", _adCore.clientID);
          
            // set refresh rate
            _adCore.refershInterval = _bannerView.adRefreshRate;
          
            _adCore.seedController = _viewController;
            _adCore.seedView = _adView;
            [_adCore setSlotNo:TadSlotBanner];
        }
        else
        {
            if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
            {
              [_delegate DAAdapterBannerView:_adView didFailToReceiveAdWithError:[DAError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
            }
          
            [self closeAd];
        }
    }
    else if (_adType == DAAdInterstitialType)
    {
        if (_adView.superview == nil)
        {
            _adView = [[UIView alloc] initWithFrame:CGRectMake(_origin.x, _origin.y,  _size.width, _size.height)];
            
            [_viewController.view addSubview:_adView];
        }
      
        _adCore = [[TadCore alloc] initWithSeedView:_adView delegate:self];
        if (_integrationKey != nil)
        {
            _adCore.clientID = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
          
            NSLog(@"_adCore.clientID : %@", _adCore.clientID);
          
            _adCore.seedController = _viewController;
            _adCore.seedView = _viewController.view;
            [_adCore setSlotNo:TadSlotInterstitial];
        }
        else
        {
            if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
            {
              [_delegate DAAdapterInterstitial:_adView didFailToReceiveAdWithError:[NSError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
            }
          
            [self closeAd];
        }
    }
    
    _adCore.delegate = self;
    _adCore.useBackFillColor = YES;
    _adCore.offset = CGPointMake(0.0f, 0.0f);
    //        _adCore.isTest = YES;
    [_adCore setLogMode:YES];
    
    [_adCore getAdvertisement];
    
}

- (void)closeAd
{
    NSLog(@"%@ : closeAd", self);
    
    [_adCore stopAd];
    
    [_adView removeFromSuperview];
    _adView = nil;
    
    if (_adType == DAAdBannerType)
    {
        
    }
    else if (_adType == DAAdInterstitialType)
    {
        
    }
    
    [_adCore destroyAd];
}

- (void)addAlignCenterConstraint
{
    // add constraints
    [_adView setTranslatesAutoresizingMaskIntoConstraints:NO];
    UIView *superview = _bannerView;
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_adView
                                  attribute:NSLayoutAttributeCenterX
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterX
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_adView
                                  attribute:NSLayoutAttributeCenterY
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterY
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView
                                                          attribute:NSLayoutAttributeHeight
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeHeight
                                                         multiplier:0.0
                                                           constant:_size.height]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView
                                                          attribute:NSLayoutAttributeWidth
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeWidth
                                                         multiplier:0.0
                                                           constant:_size.width]];
}

#pragma mark - TadDelegate
- (void)tadOnAdWillLoad:(TadCore *)tadCore
{
    
}

- (void)tadOnAdLoaded:(TadCore *)tadCore
{
    
    NSLog(@"tadCore : %@, _adView : %@", tadCore, _adView);
    
    if (_adType == DAAdBannerType)
    {
        if ([_delegate respondsToSelector:@selector(DAAdapterBannerViewDidLoadAd:adapter:)])
        {
            [_delegate DAAdapterBannerViewDidLoadAd:_adView adapter:self];
        }
    }
    else if (_adType == DAAdInterstitialType)
    {
        [_adCore showAd];
        
        if ([_delegate respondsToSelector:@selector(DAAdapterInterstitialAdDidLoadAd:)])
        {
            [_delegate DAAdapterInterstitialAdDidLoadAd:_adView];
        }
    }
}

- (void)tadOnAdClicked:(TadCore *)tadCore
{
    NSLog(@"tadCore : %@", tadCore);
}

- (void)tadOnAdTouchDown:(TadCore *)tadCore
{
    
}


// 전면형 추가 프로토콜
- (void)tadOnAdClosed:(TadCore *)tadCore
{
    
}

// Mraid 추가 프로토콜
- (void)tadOnAdExpanded:(TadCore *)tadCore
{
    
}

- (void)tadOnAdExpandClose:(TadCore *)tadCore
{
    
}

- (void)tadOnAdResized:(TadCore *)tadCore
{
    
}


- (void)tadOnAdResizeClosed:(TadCore *)tadCore
{
    
}

// 에러 처리
- (void)tadCore:(TadCore *)tadCore tadOnAdFailed:(TadErrorCode)errorCode
{
    NSLog(@"tadCore : %@, errorCode : %u", tadCore, errorCode);
    
    if (_adType == DAAdBannerType)
    {
        if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
        {
            [_delegate DAAdapterBannerView:_adView didFailToReceiveAdWithError:[NSError errorWithDomain:@"TAdAdapter" code:errorCode userInfo:nil] adapter:self];
        }
    }
    else if (_adType == DAAdInterstitialType)
    {
        if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
        {
            [_delegate DAAdapterInterstitial:_adView didFailToReceiveAdWithError:[NSError errorWithDomain:@"TAd" code:errorCode userInfo:nil] adapter:self];
        }
    }
    
    [self closeAd];
}


@end