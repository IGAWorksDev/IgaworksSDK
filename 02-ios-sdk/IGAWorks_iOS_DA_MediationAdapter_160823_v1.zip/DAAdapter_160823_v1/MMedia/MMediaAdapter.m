//
//  MMediaAdapter.m
//  IgaworksAd
//
//  Created by wonje,song on 2014. 4. 30..
//  Copyright (c) 2014년 wonje,song. All rights reserved.
//

#import "MMediaAdapter.h"

static inline NSString *DAErrorString(DAErrorCode code)
{
  switch (code)
  {
    case DAException:
      return @"Exception";
    case DAInvalidParameter:
      return @"Invalid Parameter";
    case DAUnknownServerError:
      return @"Unknown Server Error";
    case DAInvalidMediaKey:
      return @"Invalid Media key";
    case DAInvalidSpotKey:
      return @"Invalid Spot key";
    case DAEmptyCampaign:
      return @"Empty Campaign";
    case DANativeSpotDoesNotInitialized:
      return @"Native Spot Does Not Initialized";
    case DAServerTimeout:
      return @"Server Timeout";
    case DALoadAdFailed:
      return @"Load Ad Failed";
    case DANoAd:
      return @"No Ad";
    case DAMediationInvalidIntegrationKey:
      return @"Invalid Integration Key";
    default: {
      return @"Success";
    }
  }
}

@interface MMediaAdapter () <MMInlineDelegate, MMInterstitialDelegate>

- (void)getAd;
- (void)addAlignCenterConstraint;

@end

@implementation MMediaAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}

#define MILLENNIAL_BANNER_AD_SIZE ((UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) ? MMInlineAdSizeLeaderboard : MMInlineAdSizeBanner)

- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(DABannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = DAAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = DAAdInterstitialType;
}

- (BOOL)isSupportInterstitialAd
{
    return YES;
}

- (void)loadAd
{
    [MMSDK setLogLevel:MMLogLevelDebug];
    [[MMSDK sharedInstance] initializeWithSettings:nil withUserSettings:nil];
    if (_adType == DAAdBannerType)
    {
        if (_bannerAdView == nil)
        {
            NSString *apId = nil;
            if (_integrationKey != nil)
            {
                apId = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
              
                NSLog(@"apId : %@", apId);
              
                _bannerAdView = [[MMInlineAd alloc] initWithPlacementId:apId adSize:MILLENNIAL_BANNER_AD_SIZE];
                _bannerAdView.delegate = self;
                // Ad banner to the view
                [_bannerView addSubview:_bannerAdView.view];
              
                [self addAlignCenterConstraint];
            }
            else
            {
                if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
                {
                  [_delegate DAAdapterBannerView:_bannerAdView.view didFailToReceiveAdWithError:[DAError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
                }
              
                [self closeAd];
            }
        }
      
      [_timer invalidate];
      _timer = nil;
      
      // Refresh the ad every 30 seconds
      _timer = [NSTimer scheduledTimerWithTimeInterval:30.0
                                                target:self
                                              selector:@selector(getAd)
                                              userInfo:nil
                                               repeats:YES];
      // Fire the first ad request now
      [_timer fire];
    }
    else if (_adType == DAAdInterstitialType)
    {
        NSString *apId = nil;
        if (_integrationKey != nil)
        {
            apId = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
          
            NSLog(@"apId : %@", apId);
            _interstitialAd = [[MMInterstitialAd alloc] initWithPlacementId:apId];
            _interstitialAd.delegate = self;
            [_interstitialAd load:nil];
        }
        else
        {
            if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
            {
              [_delegate DAAdapterInterstitial:nil didFailToReceiveAdWithError:[NSError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
            }
          
            [self closeAd];
        }
    }
    else
    {
      
    }
  
  
}
- (void)closeAd
{
    NSLog(@"%@ : closeAd", self);
  
    if (_adType == DAAdBannerType)
    {
        [_timer invalidate];
        _timer = nil;

        [_bannerAdView.view removeFromSuperview];
        _bannerAdView.delegate = nil;
        _bannerAdView = nil;
    }
    else if (_adType == DAAdInterstitialType)
    {
        if(_interstitialAd != nil)
        {
            _interstitialAd.delegate = nil;
            _interstitialAd = nil;
        }
    }
}

- (void)getAd {
    // Get a banner ad
    [_bannerAdView request:nil];
}

#pragma mark - Inline Delegate

- (void)inlineAdRequestDidSucceed:(MMInlineAd *)ad {
    NSLog(@"Inline request succeeded.");
    
    if ([_delegate respondsToSelector:@selector(DAAdapterBannerViewDidLoadAd:adapter:)])
    {
        [_delegate DAAdapterBannerViewDidLoadAd:_bannerAdView.view adapter:self];
    }
}

- (void)inlineAd:(MMInlineAd *)ad requestDidFailWithError:(NSError *)error {
    NSLog(@"Inline ad failed: %@.", error);
    if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate DAAdapterBannerView:_bannerAdView.view didFailToReceiveAdWithError:error adapter:self];
    }
    
    [self closeAd];
}

- (void)inlineAdContentTapped:(MMInlineAd *)ad {
    NSLog(@"Inline ad tapped.");
}

- (void)inlineAd:(MMInlineAd *)ad willResizeTo:(CGRect)frame isClosing:(BOOL)isClosingResize {
    NSLog(@"Inline ad is %@ and will resize to frame %@.", isClosingResize ? @"closing" : @"resizing", NSStringFromCGRect(frame));
}

- (void)inlineAd:(MMInlineAd *)ad didResizeTo:(CGRect)frame isClosing:(BOOL)isClosingResize {
    NSLog(@"Inline ad is %@ and did resize to frame %@.", isClosingResize ? @"closing" : @"resizing", NSStringFromCGRect(frame));
}

- (void)inlineAdWillPresentModal:(MMInlineAd *)ad {
    NSLog(@"Inline ad will present modal view.");
}

- (void)inlineAdDidPresentModal:(MMInlineAd *)ad {
    NSLog(@"Inline ad did present modal view.");
}

- (void)inlineAdWillCloseModal:(MMInlineAd *)ad {
    NSLog(@"Inline ad will close modal view.");
}

- (void)inlineAdDidCloseModal:(MMInlineAd *)ad {
    NSLog(@"Inline ad did close modal view.");
}

- (void)inlineAdWillLeaveApplication:(MMInlineAd *)ad {
    NSLog(@"Inline ad will leave application.");
}

- (UIViewController *)viewControllerForPresentingModalView {
    return _viewController;
}

#pragma mark - Interstitial Delegate
- (void)interstitialAdLoadDidSucceed:(MMInterstitialAd *)ad {
    NSLog(@"Interstitial did load.");
    if (_interstitialAd.ready) {
        [_interstitialAd showFromViewController:_viewController];
    }
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitialAdDidLoadAd:)])
    {
        [_delegate DAAdapterInterstitialAdDidLoadAd:self];
    }
}

- (void)interstitialAd:(MMInterstitialAd *)ad loadDidFailWithError:(NSError *)error {
    NSLog(@"Interstitial load failed: %@.", error);
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate DAAdapterInterstitial:self didFailToReceiveAdWithError:error adapter:self];
    }
}

- (void)interstitialAdWillDisplay:(MMInterstitialAd *)ad {
    NSLog(@"Interstitial will display.");
}

- (void)interstitialAdDidDisplay:(MMInterstitialAd *)ad {
    NSLog(@"Interstitial did display.");
}

- (void)interstitialAdWillDismiss:(MMInterstitialAd *)ad {
    NSLog(@"Interstitial will dismiss.");
}

- (void)interstitialAdDidDismiss:(MMInterstitialAd *)ad {
    NSLog(@"Interstitial did dismiss.");
}

- (void)interstitialAdTapped:(MMInterstitialAd *)ad {
    NSLog(@"Interstitial tapped.");
}

- (void)interstitialAdWillLeaveApplication:(MMInterstitialAd *)ad {
    NSLog(@"Interstitial ad will leave application.");
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitialWillLeaveApplication:)])
    {
        [_delegate DAAdapterInterstitialWillLeaveApplication:ad];
    }
}


- (void)addAlignCenterConstraint
{
    // add constraints
    [_bannerAdView.view setTranslatesAutoresizingMaskIntoConstraints:NO];
    UIView *superview = _bannerView;
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_bannerAdView.view
                                  attribute:NSLayoutAttributeCenterX
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterX
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_bannerAdView.view
                                  attribute:NSLayoutAttributeCenterY
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterY
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_bannerAdView.view
                                                          attribute:NSLayoutAttributeHeight
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeHeight
                                                         multiplier:0.0
                                                           constant:_size.height]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_bannerAdView.view
                                                          attribute:NSLayoutAttributeWidth
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeWidth
                                                         multiplier:0.0
                                                           constant:_size.width]];
}
@end
