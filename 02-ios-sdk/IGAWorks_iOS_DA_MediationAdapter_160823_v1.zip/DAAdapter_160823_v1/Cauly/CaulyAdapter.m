//
//  CaulyAdapter.m
//  IgaworksAd
//
//  Created by wonje,song on 2014. 4. 10..
//  Copyright (c) 2014년 wonje,song. All rights reserved.
//

#import "CaulyAdapter.h"

static inline NSString *DAErrorString(DAErrorCode code)
{
  switch (code)
  {
    case DAException:
      return @"Exception";
    case DAInvalidParameter:
      return @"Invalid Parameter";
    case DAUnknownServerError:
      return @"Unknown Server Error";
    case DAInvalidMediaKey:
      return @"Invalid Media key";
    case DAInvalidSpotKey:
      return @"Invalid Spot key";
    case DAEmptyCampaign:
      return @"Empty Campaign";
    case DANativeSpotDoesNotInitialized:
      return @"Native Spot Does Not Initialized";
    case DAServerTimeout:
      return @"Server Timeout";
    case DALoadAdFailed:
      return @"Load Ad Failed";
    case DANoAd:
      return @"No Ad";
    case DAMediationInvalidIntegrationKey:
      return @"Invalid Integration Key";
    default: {
      return @"Success";
    }
  }
}


@interface CaulyAdapter () <CaulyAdViewDelegate, CaulyInterstitialAdDelegate>
{

}

- (void)addAlignCenterConstraint;

@end

@implementation CaulyAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;


- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}


- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(DABannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = DAAdBannerType;
    
    
    [CaulyAdSetting setLogLevel:CaulyLogLevelDebug];
    CaulyAdSetting * adSetting = [CaulyAdSetting globalSetting];
    
    
    if (_integrationKey != nil)
    {
        adSetting.appCode = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
      
        NSLog(@"adSetting.appCode : %@", adSetting.appCode);
      
        adSetting.animType = CaulyAnimCurlUp;
        adSetting.useGPSInfo = NO;
        adSetting.adSize = CaulyAdSize_IPhone;
    }
    else
    {
      if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
      {
        [_delegate DAAdapterBannerView:_adView didFailToReceiveAdWithError:[DAError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
      }
    }
}


- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = DAAdInterstitialType;
    
    [CaulyAdSetting setLogLevel:CaulyLogLevelDebug];
    CaulyAdSetting * adSetting = [CaulyAdSetting globalSetting];
    
    if (_integrationKey != nil)
    {
        adSetting.appCode = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
        NSLog(@"adSetting.appCode : %@", adSetting.appCode);
      
        adSetting.animType = CaulyAnimCurlUp;
        adSetting.useGPSInfo = NO;
        adSetting.adSize = CaulyAdSize_IPhone;
    }
    else
    {
      if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
      {
        [_delegate DAAdapterBannerView:_adView didFailToReceiveAdWithError:[DAError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
      }
    }
}

- (BOOL)isSupportInterstitialAd
{
    return YES;
}

- (void)loadAd
{
    if (_adType == DAAdBannerType)
    {
        _adView = [[CaulyAdView alloc] initWithParentViewController:_viewController];
        _adView.frame = CGRectMake(0.0f, 0.0f, _size.width, _size.height);
        _adView.delegate = self;
        
        // add banner view
        [_bannerView addSubview:_adView];
        
        [self addAlignCenterConstraint];
        
        [_adView startBannerAdRequest];
    }
    else if (_adType == DAAdInterstitialType)
    {
        _interstitialAd = [[CaulyInterstitialAd alloc] initWithParentViewController:_viewController];
        _interstitialAd.delegate = self;
        
        [_interstitialAd startInterstitialAdRequest];
    }
}

- (void)closeAd
{
    NSLog(@"%@ : closeAd", self);
    
    
    [_adView stopAdRequest];
    
    [_adView removeFromSuperview];
    _adView = nil;
    
    if (_adType == DAAdBannerType)
    {
        
    }
    else if (_adType == DAAdInterstitialType)
    {
    
    }
}

- (void)addAlignCenterConstraint
{
    // add constraints
    [_adView setTranslatesAutoresizingMaskIntoConstraints:NO];
    UIView *superview = _bannerView;
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_adView
                                  attribute:NSLayoutAttributeCenterX
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterX
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_adView
                                  attribute:NSLayoutAttributeCenterY
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterY
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView
                                                          attribute:NSLayoutAttributeHeight
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeHeight
                                                         multiplier:0.0
                                                           constant:_size.height]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView
                                                          attribute:NSLayoutAttributeWidth
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeWidth
                                                         multiplier:0.0
                                                           constant:_size.width]];
}

#pragma mark - CaulyAdViewDelegate

// 광고 정보 수신 성공
- (void)didReceiveAd:(CaulyAdView *)adView isChargeableAd:(BOOL)isChargeableAd
{
    
    if ([_delegate respondsToSelector:@selector(DAAdapterBannerViewDidLoadAd:adapter:)])
    {
        [_delegate DAAdapterBannerViewDidLoadAd:adView adapter:self];
    }
}


// 광고 정보 수신 실패
- (void)didFailToReceiveAd:(CaulyAdView *)adView errorCode:(int)errorCode errorMsg:(NSString *)errorMsg
{
    
    NSLog(@"errorCode : %d, errorMsg : %@", errorCode, errorMsg);
    
    if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate DAAdapterBannerView:adView didFailToReceiveAdWithError:[NSError errorWithDomain:@"CaulyAdapter" code:errorCode userInfo:[NSDictionary dictionaryWithObjectsAndKeys:errorMsg, NSLocalizedDescriptionKey, nil]] adapter:self];
    }
    
    [self closeAd];
    
}

// 랜딩 화면 표시
- (void)willShowLandingView:(CaulyAdView *)adView
{

}

// 랜딩 화면이 닫혔을 때
- (void)didCloseLandingView:(CaulyAdView *)adView
{

}

#pragma mark - CaulyInterstitialAdDelegate
// 광고 정보 수신 성공
- (void)didReceiveInterstitialAd:(CaulyInterstitialAd *)interstitialAd isChargeableAd:(BOOL)isChargeableAd
{
    
    NSLog(@"interstitialAd : %@, isChargeableAd : %d", interstitialAd, isChargeableAd);
    
    [interstitialAd show];
    
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitialAdDidLoadAd:)])
    {
        [_delegate DAAdapterInterstitialAdDidLoadAd:interstitialAd];
    }
}

// 광고 정보 수신 실패
- (void)didFailToReceiveInterstitialAd:(CaulyInterstitialAd *)interstitialAd errorCode:(int)errorCode errorMsg:(NSString *)errorMsg
{
    
    [self closeAd];
    
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate DAAdapterInterstitial:interstitialAd didFailToReceiveAdWithError:[NSError errorWithDomain:@"Cauly" code:errorCode userInfo:[NSDictionary dictionaryWithObjectsAndKeys:errorMsg, NSLocalizedDescriptionKey, nil]] adapter:self];
    }
}

// Interstitial 형태의 광고가 보여지기 직전
- (void)willShowInterstitialAd:(CaulyInterstitialAd *)interstitialAd
{

}

// Interstitial 형태의 광고가 닫혔을 때
- (void)didCloseInterstitialAd:(CaulyInterstitialAd *)interstitialAd
{

}


@end
