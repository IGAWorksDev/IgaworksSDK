//
//  FANAdapter.m
//  AdPopcornQAApp
//
//  Created by 김민석 on 2016. 8. 23..
//  Copyright © 2016년 igaworks. All rights reserved.
//

#import "FANAdapter.h"

static inline NSString *DAErrorString(DAErrorCode code)
{
    switch (code)
    {
        case DAException:
            return @"Exception";
        case DAInvalidParameter:
            return @"Invalid Parameter";
        case DAUnknownServerError:
            return @"Unknown Server Error";
        case DAInvalidMediaKey:
            return @"Invalid Media key";
        case DAInvalidSpotKey:
            return @"Invalid Spot key";
        case DAEmptyCampaign:
            return @"Empty Campaign";
        case DANativeSpotDoesNotInitialized:
            return @"Native Spot Does Not Initialized";
        case DAServerTimeout:
            return @"Server Timeout";
        case DALoadAdFailed:
            return @"Load Ad Failed";
        case DANoAd:
            return @"No Ad";
        case DAMediationInvalidIntegrationKey:
            return @"Invalid Integration Key";
        default: {
            return @"Success";
        }
    }
}

@interface FANAdapter () <FBAdViewDelegate, FBInterstitialAdDelegate, FBNativeAdDelegate>
{
    
}

- (void)addAlignCenterConstraint;

@end

@implementation FANAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}


- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(DABannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = DAAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = DAAdInterstitialType;
}

- (void)setNativeAdType
{
    _adType = DANativeAdType;
}

- (BOOL)isSupportInterstitialAd
{
    return YES;
}

- (void)loadAd
{
    if (_adType == DAAdBannerType)
    {
        if (_adView.superview == nil)
        {
            if (_integrationKey != nil)
            {
                NSString *placementID = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
                _adView = [[FBAdView alloc] initWithPlacementID:placementID
                                                         adSize:kFBAdSizeHeight50Banner
                                             rootViewController:_viewController];
                
                _adView.frame = CGRectMake(0.0f, 0.0f, _size.width, _size.height);
                _adView.delegate = self;
                _adView.autoresizingMask = UIViewAutoresizingFlexibleWidth;

                NSLog(@"FB Banner placementID : %@", placementID);
                // add banner view
                [_bannerView addSubview:_adView];
                
                [self addAlignCenterConstraint];
                
                
                [_adView loadAd];
            }
            else
            {
                if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
                {
                    
                    [_delegate DAAdapterBannerView:_adView didFailToReceiveAdWithError:[DAError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
                }
                
                [self closeAd];
            }
        }
    }
    else if (_adType == DAAdInterstitialType)
    {
        if (_integrationKey != nil)
        {
            NSString *placementID = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
            _interstitialAd = [[FBInterstitialAd alloc] initWithPlacementID:placementID];
            _interstitialAd.delegate = self;
            
            NSLog(@"FB Interstitial placementID : %@", placementID);
            [_interstitialAd loadAd];
        }
        else
        {
            if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
            {
                [_delegate DAAdapterInterstitial:_interstitialAd didFailToReceiveAdWithError:[NSError errorWithDomain:kDAErrorDomain code:DAMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: DAErrorString(DAMediationInvalidIntegrationKey)}] adapter:self];
            }
            
            [self closeAd];
        }
    }
    else if (_adType == DANativeAdType)
    {
        NSString *placementID = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
        if(placementID != nil)
        {
            _nativeAd = [[FBNativeAd alloc] initWithPlacementID:placementID];
            _nativeAd.delegate = self;
            [_nativeAd loadAd];
        }
    }
}


- (void)closeAd
{
    if (_adType == DAAdBannerType)
    {
        [_adView removeFromSuperview];
        _adView = nil;
    }
    else if (_adType == DAAdInterstitialType)
    {
        _interstitialAd = nil;
    }
}


- (void)setAge:(NSInteger)age
{
}

- (void)setGender:(DAGender)gender
{
}


- (void)addAlignCenterConstraint
{
    // add constraints
    if(_adView != nil)
    {
            [_adView setTranslatesAutoresizingMaskIntoConstraints:NO];
        UIView *superview = _bannerView;
        [superview addConstraint:
         [NSLayoutConstraint constraintWithItem:_adView
                                  attribute:NSLayoutAttributeCenterX
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterX
                                 multiplier:1
                                   constant:0]];
    
        [superview addConstraint:
         [NSLayoutConstraint constraintWithItem:_adView
                                  attribute:NSLayoutAttributeCenterY
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterY
                                 multiplier:1
                                   constant:0]];
    
        [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView
                                                          attribute:NSLayoutAttributeHeight
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeHeight
                                                         multiplier:0.0
                                                           constant:_size.height]];
    
        [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adView
                                                          attribute:NSLayoutAttributeWidth
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeWidth
                                                         multiplier:0.0
                                                           constant:_size.width]];
    }
}

#pragma mark - FBAdViewDelegate
- (void)adView:(FBAdView *)adView didFailWithError:(NSError *)error;
{
    NSLog(@"Banner Ad failed to load");
    // Add code to hide the ad unit...
    adView.hidden = YES;
    if ([_delegate respondsToSelector:@selector(DAAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate DAAdapterBannerView:adView didFailToReceiveAdWithError:error adapter:self];
    }
}

- (void)adViewDidLoad:(FBAdView *)adView;
{
    NSLog(@"Banner Ad was loaded and ready to be displayed");
    // Add code to show the ad unit...
    adView.hidden = NO;
    if ([_delegate respondsToSelector:@selector(DAAdapterBannerViewDidLoadAd:adapter:)])
    {
        [_delegate DAAdapterBannerViewDidLoadAd:adView adapter:self];
    }
}

#pragma mark - FBInterstitialAdDelegate
- (void)interstitialAdDidLoad:(FBInterstitialAd *)interstitialAd
{
    NSLog(@"Interstitial Ad is loaded and ready to be displayed");
    
    // You can now display the full screen ad using this code:
    [interstitialAd showAdFromRootViewController:_viewController];
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitialAdDidLoadAd:)])
    {
        [_delegate DAAdapterInterstitialAdDidLoadAd:interstitialAd];
    }
}

- (void)interstitialAd:(FBInterstitialAd *)interstitialAd didFailWithError:(NSError *)error
{
    NSLog(@"Interstitial Ad failed to load");
    [self closeAd];
    
    if ([_delegate respondsToSelector:@selector(DAAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate DAAdapterInterstitial:interstitialAd didFailToReceiveAdWithError:error adapter:self];
    }
}

#pragma mark - FBNativeAdDelegate
- (void)nativeAdDidLoad:(FBNativeAd *)nativeAd
{
    NSLog(@"nativeAdDidLoad...%@", nativeAd);
    if ([_delegate respondsToSelector:@selector(DAAdapterNativeAdDidLoadAd:networkName:)])
    {
        [_delegate DAAdapterNativeAdDidLoadAd:nativeAd networkName:@"FAN_Native"];
    }
}

- (void)nativeAd:(FBNativeAd *)nativeAd didFailWithError:(NSError *)error
{
    NSLog(@"FAN Native ad failed to load with error: %@", error);
    if ([_delegate respondsToSelector:@selector(DAAdapterNativeAd:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate DAAdapterNativeAd:nativeAd didFailToReceiveAdWithError:error adapter:self];
    }
}

- (void)nativeAdDidClick:(FBNativeAd *)nativeAd
{
    NSLog(@"FAN Native ad was clicked.");
}

- (void)nativeAdDidFinishHandlingClick:(FBNativeAd *)nativeAd
{
    NSLog(@"FAN Native ad did finish click handling.");
}

- (void)nativeAdWillLogImpression:(FBNativeAd *)nativeAd
{
    NSLog(@"FAN Native ad impression is being captured.");
}

@end