//
//  FANAdapter.h
//  AdPopcornQAApp
//
//  Created by 김민석 on 2016. 8. 23..
//  Copyright © 2016년 igaworks. All rights reserved.
//

#import <AdPopcornDA/DAAdapter.h>

#import <FBAudienceNetwork/FBAudienceNetwork.h>

@interface FANAdapter : DAAdapter
{
    FBAdView *_adView;
    FBInterstitialAd *_interstitialAd;
    FBNativeAd *_nativeAd;
}
@end