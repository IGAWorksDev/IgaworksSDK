//
//  MPMoPubNativeCustomEvent.h
//  MoPubSDK
//
//  Copyright (c) 2014 MoPub. All rights reserved.
//

#import "MPNativeCustomEvent.h"

@interface MPMoPubNativeCustomEvent : MPNativeCustomEvent

@end
