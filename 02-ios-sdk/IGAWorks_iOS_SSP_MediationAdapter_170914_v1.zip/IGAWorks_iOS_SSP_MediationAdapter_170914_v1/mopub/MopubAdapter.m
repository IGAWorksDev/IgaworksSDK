//
//  MopubAdapter.m
//  AdPopcornSSP
//
//  Created by mick on 2017. 8. 2..
//  Copyright (c) 2017년 igaworks All rights reserved.
//

#import "MopubAdapter.h"

static inline NSString *SSPErrorString(SSPErrorCode code)
{
    switch (code)
    {
        case AdPopcornSSPException:
            return @"Exception";
        case AdPopcornSSPInvalidParameter:
            return @"Invalid Parameter";
        case AdPopcornSSPUnknownServerError:
            return @"Unknown Server Error";
        case AdPopcornSSPInvalidMediaKey:
            return @"Invalid Media key";
        case AdPopcornSSPInvalidPlacementKey:
            return @"Invalid Placement key";
        case AdPopcornSSPEmptyCampaign:
            return @"Empty Campaign";
        case AdPopcornSSPNativePlacementDoesNotInitialized:
            return @"Native Placement Does Not Initialized";
        case AdPopcornSSPServerTimeout:
            return @"Server Timeout";
        case AdPopcornSSPLoadAdFailed:
            return @"Load Ad Failed";
        case AdPopcornSSPNoAd:
            return @"No Ad";
        case AdPopcornSSPMediationInvalidIntegrationKey:
            return @"Invalid Integration Key";
        default: {
            return @"Success";
        }
    }
}

@interface MopubAdapter () <MPAdViewDelegate, MPInterstitialAdControllerDelegate>
{
    
}

- (void)addAlignCenterConstraint;

@end

@implementation MopubAdapter

@synthesize delegate = _delegate;
@synthesize integrationKey = _integrationKey;

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}


- (void)setViewController:(UIViewController *)viewController origin:(CGPoint)origin size:(CGSize)size bannerView:(AdPopcornSSPBannerView *)bannerView
{
    _viewController = viewController;
    _origin = origin;
    _size = size;
    _bannerView = bannerView;
    _adType = SSPAdBannerType;
}

- (void)setViewController:(UIViewController *)viewController
{
    _viewController = viewController;
    _adType = SSPAdInterstitialType;
}

- (BOOL)isSupportInterstitialAd
{
    return YES;
}

- (void)loadAd
{
    if (_adType == SSPAdBannerType)
    {
        if (_integrationKey != nil)
        {
            NSString *adUnitID = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
            
            if(_size.width == 300.0f && _size.height == 250.0f)
            {
                _adBannerView = [[MPAdView alloc] initWithAdUnitId:adUnitID
                                                              size:MOPUB_MEDIUM_RECT_SIZE];
                _adBannerView.frame = CGRectMake((_bannerView.bounds.size.width - MOPUB_MEDIUM_RECT_SIZE.width) / 2,
                                                 _bannerView.bounds.size.height - MOPUB_MEDIUM_RECT_SIZE.height,
                                                 MOPUB_MEDIUM_RECT_SIZE.width, MOPUB_MEDIUM_RECT_SIZE.height);
                

            }
            else
            {
                
                _adBannerView = [[MPAdView alloc] initWithAdUnitId:adUnitID
                                                              size:MOPUB_BANNER_SIZE];
                _adBannerView.frame = CGRectMake((_bannerView.bounds.size.width - MOPUB_BANNER_SIZE.width) / 2,
                                                 _bannerView.bounds.size.height - MOPUB_BANNER_SIZE.height,
                                                 MOPUB_BANNER_SIZE.width, MOPUB_BANNER_SIZE.height);
            }
            // add banner view
            [_bannerView addSubview:_adBannerView];
            
            [self addAlignCenterConstraint];
            
            NSLog(@"_adBannerView.adUnitID : %@", adUnitID);
          
            _adBannerView.delegate = self;
            
            // load request
            [_adBannerView loadAd];
        }
        else
        {
          if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
          {
              [_delegate AdPopcornSSPAdapterBannerView:_adBannerView didFailToReceiveAdWithError:[AdPopcornSSPError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
          }
          
          [self closeAd];
        }
    }
    else if (_adType == SSPAdInterstitialType)
    {
        if (_integrationKey != nil)
        {
            NSString *adUnitID = [_integrationKey valueForKey:[[_integrationKey allKeys] firstObject]];
            
            _interstitial = [MPInterstitialAdController
                             interstitialAdControllerForAdUnitId:adUnitID];
            _interstitial.delegate = self;
            // Fetch the interstitial ad.
            [_interstitial loadAd];
            // Note: Edit SampleConstants.h to update kSampleAdUnitId with your interstitial ad unit id.
        }
        else
        {
            if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
            {
                [_delegate AdPopcornSSPAdapterInterstitial:_interstitial didFailToReceiveAdWithError:[NSError errorWithDomain:kAdPopcornSSPErrorDomain code:AdPopcornSSPMediationInvalidIntegrationKey userInfo:@{NSLocalizedDescriptionKey: SSPErrorString(AdPopcornSSPMediationInvalidIntegrationKey)}] adapter:self];
            }
            
            [self closeAd];
        }
    }
}

- (void)closeAd
{
    NSLog(@"%@ : closeAd", self);
    
    if (_adType == SSPAdBannerType)
    {
        [_adBannerView removeFromSuperview];
        _adBannerView = nil;
    }
    else if (_adType == SSPAdInterstitialType)
    {
        _interstitial = nil;
    }
}

- (void)showAd
{
    NSLog(@"%@ : showAd", self);
    
    if (_adType == SSPAdInterstitialType)
    {
        if (_interstitial.ready)
            [_interstitial showFromViewController:_viewController];
    }
}

- (void)loadRequest
{
    if (_adType == SSPAdBannerType)
    {
        [_adBannerView loadAd];
    }
    else if (_adType == SSPAdInterstitialType)
    {
        [_interstitial loadAd];
    }
}

- (void)addAlignCenterConstraint
{
    // add constraints
    [_adBannerView setTranslatesAutoresizingMaskIntoConstraints:NO];
    UIView *superview = _bannerView;
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_adBannerView
                                  attribute:NSLayoutAttributeCenterX
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterX
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:
     [NSLayoutConstraint constraintWithItem:_adBannerView
                                  attribute:NSLayoutAttributeCenterY
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:superview
                                  attribute:NSLayoutAttributeCenterY
                                 multiplier:1
                                   constant:0]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adBannerView
                                                          attribute:NSLayoutAttributeHeight
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeHeight
                                                         multiplier:0.0
                                                           constant:_size.height]];
    
    [superview addConstraint:[NSLayoutConstraint constraintWithItem:_adBannerView
                                                          attribute:NSLayoutAttributeWidth
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:superview
                                                          attribute:NSLayoutAttributeWidth
                                                         multiplier:0.0
                                                           constant:_size.width]];
}

#pragma mark - MPAdViewDelegate
- (UIViewController *)viewControllerForPresentingModalView {
    NSLog(@"viewControllerForPresentingModalView");
    return _viewController;
}

- (void)adViewDidLoadAd:(MPAdView *)view
{
    NSLog(@"adViewDidLoadAd : %@", view);
    
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewDidLoadAd:adapter:)])
    {
        [_delegate AdPopcornSSPAdapterBannerViewDidLoadAd:view adapter:self];
    }
}

- (void)adViewDidFailToLoadAd:(MPAdView *)view
{
    NSLog(@"adViewDidFailToLoadAd : %@", view);
    
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerView:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate AdPopcornSSPAdapterBannerView:view didFailToReceiveAdWithError:nil adapter:self];
    }
    [self closeAd];
}

- (void)willPresentModalViewForAd:(MPAdView *)view
{
    NSLog(@"willPresentModalViewForAd : %@", view);
}

- (void)didDismissModalViewForAd:(MPAdView *)view
{
    NSLog(@"didDismissModalViewForAd : %@", view);
}

- (void)willLeaveApplicationFromAd:(MPAdView *)view
{
    NSLog(@"willLeaveApplicationFromAd : %@", view);
    
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterBannerViewWillLeaveApplication:)])
    {
        [_delegate AdPopcornSSPAdapterBannerViewWillLeaveApplication:view];
    }
}

#pragma mark - MPInterstitialAdControllerDelegate
- (void)interstitialDidLoadAd:(MPInterstitialAdController *)interstitial
{
    NSLog(@"interstitialDidLoadAd : %@", interstitial);

    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialAdDidLoadAd:)])
    {
        [_delegate AdPopcornSSPAdapterInterstitialAdDidLoadAd:interstitial];
    }
}

- (void)interstitialDidFailToLoadAd:(MPInterstitialAdController *)interstitial
{
    NSLog(@"interstitialDidFailToLoadAd : %@", interstitial);
    [self closeAd];
    
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitial:didFailToReceiveAdWithError:adapter:)])
    {
        [_delegate AdPopcornSSPAdapterInterstitial:interstitial didFailToReceiveAdWithError:nil adapter:self];
    }
}

- (void)interstitialWillAppear:(MPInterstitialAdController *)interstitial
{
    NSLog(@"interstitialWillAppear : %@", interstitial);
}

- (void)interstitialDidAppear:(MPInterstitialAdController *)interstitial
{
    NSLog(@"interstitialDidAppear : %@", interstitial);
}

- (void)interstitialWillDisappear:(MPInterstitialAdController *)interstitial
{
    NSLog(@"interstitialWillDisappear : %@", interstitial);
}

- (void)interstitialDidDisappear:(MPInterstitialAdController *)interstitial
{
    NSLog(@"interstitialDidDisappear : %@", interstitial);
}

- (void)interstitialDidExpire:(MPInterstitialAdController *)interstitial
{
    NSLog(@"interstitialDidExpire : %@", interstitial);
}

- (void)interstitialDidReceiveTapEvent:(MPInterstitialAdController *)interstitial
{
    NSLog(@"interstitialDidReceiveTapEvent : %@", interstitial);
    if ([_delegate respondsToSelector:@selector(AdPopcornSSPAdapterInterstitialWillLeaveApplication:)])
    {
        [_delegate AdPopcornSSPAdapterInterstitialWillLeaveApplication:interstitial];
    }
}

@end
