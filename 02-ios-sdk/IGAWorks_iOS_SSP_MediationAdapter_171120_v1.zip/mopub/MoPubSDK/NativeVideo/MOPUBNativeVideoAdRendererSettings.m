//
//  MOPUBNativeVideoAdRendererSettings.m
//  Copyright (c) 2015 MoPub. All rights reserved.
//

#import "MOPUBNativeVideoAdRendererSettings.h"

@implementation MOPUBNativeVideoAdRendererSettings

@end
